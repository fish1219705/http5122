﻿/* LAB 8-1 - FINAL COUNTDOWN!! */


//create page load listener

//create page load function

	//create variables for required HTML elements
	
	//create variables for now date and due date
	
	//OUTPUT NOW DATE & DUE DATE TO HTML PAGE
	
	//CONVERT TO UTC AND SUBTRACT TO GET TIME DIFFERENCE
	
	//CONVERT TIME DIFFERENCE TO WHOLE NUMBER OF DAYS
		
	//LOGIC TO CHECK IF DUE DATE HAS PASSED, AND OUPUT APPROPRIATE MESSAGE TO HTML PAGE